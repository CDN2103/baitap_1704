#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define PORT 9999
#define MAXLINE 1024

int main() {
    int sockfd;
    struct sockaddr_in servaddr;
    char buffer[MAXLINE*2+1];

    // Tạo socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation error");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Thiết lập thông tin địa chỉ của server
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Kết nối đến server
    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    // Nhập tên máy tính và số ổ đĩa từ bàn phím
    char hostname[256];
    char drivelist[MAXLINE];
    printf("Enter hostname: ");
    scanf("%s", hostname);
    printf("Enter number of drives: ");
    int num_drives;
    scanf("%d", &num_drives);

    // Nhập thông tin cho từng ổ đĩa
    char drive[MAXLINE];
    char size[MAXLINE];
    char entry[MAXLINE*2+1];
    strcpy(drivelist, "");
    for (int i = 0; i < num_drives; i++) {
        printf("Enter drive %d: ", i + 1);
        scanf("%s", drive);
        printf("Enter size of drive %d: ", i + 1);
        scanf("%s", size);
        sprintf(entry, "%s-%s ", drive, size);
        strcat(drivelist, entry);
    }

    // Đóng gói và gửi dữ liệu đến server
    sprintf(buffer, "%s|%s", hostname, drivelist);
    send(sockfd, buffer, strlen(buffer), 0);

    printf("Data sent to server\n");

    close(sockfd);
    return 0;
}
