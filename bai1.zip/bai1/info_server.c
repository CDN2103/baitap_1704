#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define PORT 9999
#define MAXLINE 1024

int main() {
    int sockfd, connfd;
    struct sockaddr_in servaddr, cliaddr;
    char buffer[MAXLINE];

    // Tạo socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation error");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // Thiết lập thông tin địa chỉ của server
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Gán địa chỉ cho socket
    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        perror("Socket binding error");
        exit(EXIT_FAILURE);
    }
    // Lắng nghe kết nối từ client
    if (listen(sockfd, 5) != 0) {
        perror("Listen error");
        exit(EXIT_FAILURE);
    }

    // Chấp nhận kết nối từ client
    socklen_t len = sizeof(cliaddr);
    connfd = accept(sockfd, (struct sockaddr*)&cliaddr, &len);
    if (connfd < 0) {
        perror("Acceptance error");
        exit(EXIT_FAILURE);
    }

    // Nhận dữ liệu từ client
    int n = read(connfd, buffer, MAXLINE);
    if (n < 0) {
        perror("Read error");
        exit(EXIT_FAILURE);
    }

    buffer[n] = '\0';

    // Tách dữ liệu thành tên máy tính và danh sách ổ đĩa
    char hostname[MAXLINE];
    char drivelist[MAXLINE];
    sscanf(buffer, "%[^|]|%[^\n]", hostname, drivelist);
    char drivelist_copy[1024]; // Tạo bản sao của chuỗi gốc
    strcpy(drivelist_copy, drivelist);
    // In thông tin lên màn hình
    printf("Hostname: %s\n", hostname);
    char* drive;
    char* size;
    int count = 0;
    char *token1 = strtok(drivelist_copy," ");
    while (token1 != NULL) {
        count++;
        token1 = strtok(NULL, " ");
    }
    printf("The number of elements in drivelist is: %d\n", count);
    printf("Drives:\n");
    char *token = strtok(drivelist, " ");
    while (token != NULL) {
        printf("%s\n", token);
        token = strtok(NULL, " ");
    }
    return 0;

    close(connfd);
    close(sockfd);
    return 0;
}