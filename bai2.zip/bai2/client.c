#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Su dung: %s <Server IP> <Port>\n", argv[0]);
        exit(1);
    }

    char *server_ip = argv[1];
    int port = atoi(argv[2]);

    // Open file
    FILE *file = fopen("data.txt", "r");
    if (file == NULL) {
        perror("fopen");
        exit(1);
    }

    // Connect to server
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("socket");
        exit(1);
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(server_ip);
    server_addr.sin_port = htons(port);

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("connect");
        exit(1);
    }

    // Read file and send to server
    char buf[BUF_SIZE];
    size_t nread;
    while ((nread = fread(buf, 1, BUF_SIZE, file)) > 0) {
        if (write(sock, buf, nread) != nread) {
            perror("write");
            exit(1);
        }
    }

    // Close file and socket
    fclose(file);
    close(sock);

    return 0;
}