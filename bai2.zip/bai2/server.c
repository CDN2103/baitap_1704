#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Su dung: %s <Port>\n", argv[0]);
        exit(1);
    }

    int port = atoi(argv[1]);

    // Create socket
    int server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        perror("socket");
        exit(1);
    }

    // Bind socket to port
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(port);

    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("bind");
        exit(1);
    }

    // Listen for connections
    if (listen(server_sock, 5) == -1) {
        perror("listen");
        exit(1);
    }

    // Accept connections and process data
    char buf[BUF_SIZE];
    int client_sock, client_addr_len;
    struct sockaddr_in client_addr;
    while (1) {
            client_addr_len = sizeof(client_addr);
    client_sock = accept(server_sock, (struct sockaddr *)&client_addr, (socklen_t *)&client_addr_len);
    if (client_sock == -1) {
        perror("accept");
        exit(1);
    }

    int count = 0; // count of "0123456789" occurrences
    int prev_match = 0; // flag for matching "0123456789" across multiple reads

    while (1) {
        ssize_t nread = read(client_sock, buf, BUF_SIZE);
        if (nread == -1) {
            perror("read");
            exit(1);
        } else if (nread == 0) {
            break; // end of file
        }

        // Search for "0123456789" in buffer
        for (int i = 0; i < nread; i++) {
            if (buf[i] == '0') {
                if (strncmp(&buf[i], "0123456789", 10) == 0) {
                    count++;
                    i += 9; // skip ahead to end of "0123456789"
                    prev_match = 1;
                } else {
                    prev_match = 0;
                }
            } else if (buf[i] == '1' && prev_match) {
                if (strncmp(&buf[i], "234567890", 9) == 0) {
                    count++;
                    i += 8; // skip ahead to end of "234567890"
                }
            } else {
                prev_match = 0;
            }
        }
    }

    // Print result to console
    printf("So lan xuat hien '0123456789': %d\n", count);

    // Close client socket
    close(client_sock);
}

// Close server socket
close(server_sock);

return 0;
}
